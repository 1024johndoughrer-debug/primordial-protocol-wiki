function updateVhsClock(){const el=document.getElementById("vhsClock");if(!el)return;const now=new Date();el.textContent=[now.getHours(),now.getMinutes(),now.getSeconds()].map(v=>String(v).padStart(2,"0")).join(":");}
updateVhsClock();setInterval(updateVhsClock,1000);
