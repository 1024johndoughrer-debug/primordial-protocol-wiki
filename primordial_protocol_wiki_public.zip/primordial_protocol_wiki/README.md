# Primordial Protocol — Official Lore Wiki

Updated with the four uploaded character images:

- Fighter — first uploaded image
- Unknown — second uploaded image
- Experiment 142 — third uploaded image
- The Abyss — fourth uploaded image

Open `index.html` to view the archive. Character pages are generated from `character.js`.
